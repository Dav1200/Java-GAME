package game;

public class item extends BackpackItem{

    public item(Player player) {
        super(player);
    }

    @Override
    public String getType() {
            return "None";}

    @Override
    public void function() {

    }
}
